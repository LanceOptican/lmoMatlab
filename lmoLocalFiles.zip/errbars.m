% add error bars
% inputs:
% x = x-values for data points
% y = data points
% err = 2-D array. Each row is a point, 1st col is low error, 2nd col is
% high error
% colr is a color spec, e.g., 'r'
% wd = width of bar, e.g., 0.05 of x spacing
function h = errbars(x, y, err, colr, wd)
n = numel(x);
dx = wd * (x(2) - x(1));
h = [];
for k = 1:n
    h = [h, plot([x(k), x(k)], y(k) + err(k, :), colr)];
    yl = y(k) + err(k, 1);
    h = [h, plot(x(k) + [-dx, dx], [yl, yl], colr)];
    yu = y(k) + err(k, 2);
    h = [h, plot(x(k) + [-dx, dx], [yu, yu], colr)];
end
