TISEAN software has a unix interface. To use it from matlab on a Windows machine,
you need an interface to unix.

On Windows, this can be accomplished by installing CYGWIN (http://www.cygwin.com/)
I wrote a little m-file, tiseanCall(), that passes all the parameters and data.

Lance Optican
