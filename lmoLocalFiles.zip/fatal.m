function fatal(test, str)
if (test)
    error(str);
end
