% timerstart -- call to start a clock timer
% global variables tstart and tend keep track of the times

global timer_start

timer_start = [];
