% startup includes path for lmoLocal files
matlabrt = 	matlabroot;

local = fullfile(matlabrt, 'toolbox', 'local', 'LMO');
addpath(local)
disp(['addpath ', local]);

% sql3 = fullfile(local, 'matlab-sqlite3-driver-master');
% addpath(sql3)
% disp(['addpath', sql3]);