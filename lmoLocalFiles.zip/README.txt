Copy the files in this directory to matlab's
toolbox/local/LSR
